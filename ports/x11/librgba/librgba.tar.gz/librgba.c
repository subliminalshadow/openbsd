/*
	Copyright 2008, Aleksey Shaferov

	RGBA module is free software: you can redistribute it and/or modify
	it under the terms of the GNU General Public License as published by
	the Free Software Foundation, either version 3 of the License, or
	(at your option) any later version.

	RGBA module is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with media-applet.  If not, see <http://www.gnu.org/licenses/>.

*/
#include <glib.h>
#include <glib/gtypes.h>
#include <gtk/gtk.h>

static	GdkColormap *colormap;


G_MODULE_EXPORT void
gtk_module_init (gint * argc, gchar *** argv)
{
    char * progname = g_get_prgname();
    gboolean rgba = FALSE;
    if (g_getenv("GTK_RGBA_APPS")) {
	gboolean not = FALSE;
	char ** apps = g_strsplit(g_getenv("GTK_RGBA_APPS"),":",-1);
	if (!g_strcmp0(apps[0],"allbut")) {
	    not = TRUE;
	    rgba = TRUE;
	};
	int i;
	for (i = 0; apps[i] != NULL;i++) {
	    if (!g_strcmp0(apps[i],progname)) {
		rgba = !not;
	    };
	};
	g_strfreev(apps);
    };
    if (rgba) {
    printf ("\nprogname=%s; RGBA=on\n",progname);
	colormap = gdk_screen_get_rgba_colormap(gdk_screen_get_default());
	gtk_widget_push_colormap(colormap);                
	gtk_widget_set_default_colormap(colormap);
    };
}
                        